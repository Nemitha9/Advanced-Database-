package com.mgmt;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TranslatorManagementApplicationTests {

	@Test
	void contextLoads() {
	}

}
